package com.example.login;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BuscadorActivity extends AppCompatActivity {

TextView correo;
TextView apodo;
TextView nombre;
TextView apellido;
ImageView insignia1;
ImageView insignia2;
ImageView insignia3;
ImageView insignia4;
ImageView insignia5;
ImageView insignia6;


EditText apodoBuscador;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscador);

        correo=findViewById(R.id.correoResultado);
        apodo=findViewById(R.id.apodoResultado);
        nombre=findViewById(R.id.nombreResultado);
        apellido=findViewById(R.id.apellidoRes);
        insignia1=findViewById(R.id.insignia1);
        insignia2=findViewById(R.id.insignia2);
        insignia3=findViewById(R.id.insignia3);
        insignia4=findViewById(R.id.insignia4);
        insignia5=findViewById(R.id.insignia5);
        insignia6=findViewById(R.id.insignia6);



        apodoBuscador=findViewById(R.id.apodoBuscador);

    }

    public void Buscador (View view){
        Call<Usuario> call = ApiClient.getUserService().getUsuario(apodoBuscador.getText().toString());

        call.enqueue(new Callback<Usuario>() {
            @Override
            public void onResponse(Call<Usuario> call, Response<Usuario> response) {
                if(response.code()==201){

                    correo.setText(response.body().getCorreo());
                    apodo.setText(response.body().getApodo());
                    nombre.setText(response.body().getNombre());
                    apellido.setText(response.body().getApellido());
                    Picasso.get().load(response.body().getInsigniasbool().


                }
            }

            @Override
            public void onFailure(Call<Usuario> call, Throwable t) {

            }
        });
    }
}